import sqlite3
import pandas as pd
from datetime import datetime

def init_db():
    conn = sqlite3.connect('restaurant.db')
    c = conn.cursor()

    # Kullanıcılar tablosu
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  is_admin INTEGER DEFAULT 0)''')

    # Ürünler tablosu (sadeleştirildi)
    c.execute('''CREATE TABLE IF NOT EXISTS products
                 (id INTEGER PRIMARY KEY,
                  name TEXT UNIQUE NOT NULL)''')

    # Stok tablosu (güncellendi)
    c.execute('''CREATE TABLE IF NOT EXISTS inventory
                 (id INTEGER PRIMARY KEY,
                  product_id INTEGER NOT NULL,
                  quantity REAL NOT NULL,
                  unit TEXT NOT NULL,
                  total_price REAL NOT NULL,
                  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_by INTEGER,
                  FOREIGN KEY (product_id) REFERENCES products (id),
                  FOREIGN KEY (updated_by) REFERENCES users (id))''')

    # Stok hareket tablosu
    c.execute('''CREATE TABLE IF NOT EXISTS inventory_movements
                 (id INTEGER PRIMARY KEY,
                  product_id INTEGER NOT NULL,
                  quantity_change REAL NOT NULL,
                  unit TEXT NOT NULL,
                  total_price REAL NOT NULL,
                  movement_type TEXT NOT NULL,
                  movement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  user_id INTEGER,
                  FOREIGN KEY (product_id) REFERENCES products (id),
                  FOREIGN KEY (user_id) REFERENCES users (id))''')

    conn.commit()
    conn.close()

def get_db():
    conn = sqlite3.connect('restaurant.db')
    conn.row_factory = sqlite3.Row
    return conn

def add_user(username, password, is_admin=0):
    if not username or not password:
        return False, "Kullanıcı adı ve şifre boş olamaz"

    conn = get_db()
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)",
                 (username, password, is_admin))
        conn.commit()
        return True, "Kullanıcı başarıyla eklendi"
    except sqlite3.IntegrityError:
        return False, "Bu kullanıcı adı zaten kullanılıyor"
    except Exception as e:
        return False, f"Beklenmeyen bir hata oluştu: {str(e)}"
    finally:
        conn.close()

def add_product(name):
    if not name:
        return False, "Ürün adı boş olamaz"

    conn = get_db()
    c = conn.cursor()
    try:
        c.execute("INSERT INTO products (name) VALUES (?)", (name,))
        conn.commit()
        return True, "Ürün başarıyla eklendi"
    except sqlite3.IntegrityError:
        return False, "Bu ürün zaten tanımlı"
    except Exception as e:
        return False, f"Beklenmeyen bir hata oluştu: {str(e)}"
    finally:
        conn.close()

def get_products():
    conn = get_db()
    df = pd.read_sql_query("SELECT * FROM products ORDER BY name", conn)
    conn.close()
    return df

def add_inventory_movement(product_id, quantity, unit, total_price, user_id):
    if not product_id or not unit or total_price < 0:
        return False, "Lütfen tüm alanları doğru şekilde doldurun"

    conn = get_db()
    c = conn.cursor()
    try:
        # Önce stok kaydını kontrol et/güncelle
        c.execute("SELECT id FROM inventory WHERE product_id = ?", (product_id,))
        inv_record = c.fetchone()

        if inv_record:
            c.execute("""UPDATE inventory 
                        SET quantity = quantity + ?,
                            unit = ?,
                            total_price = total_price + ?,
                            last_updated = CURRENT_TIMESTAMP,
                            updated_by = ?
                        WHERE product_id = ?""",
                     (quantity, unit, total_price, user_id, product_id))
        else:
            c.execute("""INSERT INTO inventory 
                        (product_id, quantity, unit, total_price, updated_by)
                        VALUES (?, ?, ?, ?, ?)""",
                     (product_id, quantity, unit, total_price, user_id))

        # Hareket kaydı ekle
        c.execute("""INSERT INTO inventory_movements 
                    (product_id, quantity_change, unit, total_price, movement_type, user_id)
                    VALUES (?, ?, ?, ?, ?, ?)""",
                 (product_id, quantity, unit, total_price, 'update', user_id))

        conn.commit()
        return True, "Stok başarıyla güncellendi"
    except sqlite3.IntegrityError:
        return False, "Ürün veya kullanıcı bulunamadı"
    except Exception as e:
        return False, f"Beklenmeyen bir hata oluştu: {str(e)}"
    finally:
        conn.close()

def get_inventory_report(start_date, end_date):
    conn = get_db()
    query = """
    SELECT 
        p.name as product_name,
        i.unit,
        i.total_price,
        i.quantity as current_quantity,
        SUM(im.quantity_change) as total_movement,
        COUNT(im.id) as movement_count,
        i.total_price as total_value
    FROM products p
    LEFT JOIN inventory i ON p.id = i.product_id
    LEFT JOIN inventory_movements im ON p.id = im.product_id
    AND im.movement_date BETWEEN ? AND ?
    GROUP BY p.id
    ORDER BY p.name
    """
    df = pd.read_sql_query(query, conn, params=[start_date, end_date])
    conn.close()
    return df

def get_inventory():
    conn = get_db()
    df = pd.read_sql_query("""
        SELECT p.name as product_name, i.* 
        FROM inventory i 
        JOIN products p ON i.product_id = p.id
    """, conn)
    conn.close()
    return df

def get_latest_inventory_movements(limit=5):
    conn = get_db()
    query = """
    SELECT 
        p.name as product_name,
        im.id as movement_id,
        im.quantity_change as quantity,
        im.unit,
        im.price,
        (im.quantity_change * im.price) as total_price,
        im.movement_date,
        datetime(im.movement_date, 'localtime') as local_date
    FROM inventory_movements im
    JOIN products p ON im.product_id = p.id
    ORDER BY im.movement_date DESC
    LIMIT ?
    """
    try:
        df = pd.read_sql_query(query, conn, params=[limit])
        return df.to_dict('records') if not df.empty else None
    except Exception as e:
        print(f"Hata: {str(e)}")
        return None
    finally:
        conn.close()

def delete_inventory_movement(movement_id):
    if not movement_id:
        return False, "Geçersiz hareket ID'si"

    conn = get_db()
    c = conn.cursor()
    try:
        # Önce hareketin detaylarını al
        c.execute("""
            SELECT product_id, quantity_change, unit
            FROM inventory_movements
            WHERE id = ?
        """, (movement_id,))
        movement = c.fetchone()

        if not movement:
            return False, "Hareket bulunamadı"

        product_id, quantity, unit = movement

        # Stok miktarını güncelle
        c.execute("""
            UPDATE inventory 
            SET quantity = quantity - ?
            WHERE product_id = ? AND unit = ?
        """, (quantity, product_id, unit))

        # Hareketi sil
        c.execute("DELETE FROM inventory_movements WHERE id = ?", (movement_id,))

        conn.commit()
        return True, "Stok hareketi başarıyla silindi"
    except Exception as e:
        return False, f"Stok hareketi silinirken hata oluştu: {str(e)}"
    finally:
        conn.close()

def delete_product(product_id):
    if not product_id:
        return False, "Geçersiz ürün ID'si"

    conn = get_db()
    c = conn.cursor()
    try:
        # İlk olarak bu ürünün stok hareketleri ve stok kaydı var mı kontrol et
        c.execute("SELECT COUNT(*) FROM inventory_movements WHERE product_id = ?", (product_id,))
        movement_count = c.fetchone()[0]

        c.execute("SELECT COUNT(*) FROM inventory WHERE product_id = ?", (product_id,))
        inventory_count = c.fetchone()[0]

        if movement_count > 0 or inventory_count > 0:
            return False, "Bu ürüne ait stok hareketleri bulunmaktadır. Önce stok kayıtlarını temizleyiniz."

        # Ürünü sil
        c.execute("DELETE FROM products WHERE id = ?", (product_id,))
        if c.rowcount == 0:
            return False, "Ürün bulunamadı"

        conn.commit()
        return True, "Ürün başarıyla silindi"
    except Exception as e:
        return False, f"Ürün silinirken hata oluştu: {str(e)}"
    finally:
        conn.close()