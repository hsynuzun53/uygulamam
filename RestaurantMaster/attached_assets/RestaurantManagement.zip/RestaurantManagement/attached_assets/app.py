import streamlit as st

# Sayfa konfigürasyonu
st.set_page_config(
    page_title="Restoran Stok Takip",
    page_icon="🏪",
    layout="wide"
)

from datetime import datetime, timedelta
from auth import init_session_state, check_auth, login_page, logout
from database import (init_db, add_product, get_products, delete_product,
                     add_inventory_movement, get_inventory_report, get_latest_inventory_movements, delete_inventory_movement)
from utils import export_to_excel, format_date

# Initialize database and session state
init_db()
init_session_state()

# Ana sayfa düzeni
if not check_auth():
    login_page()
else:
    st.sidebar.title(f"Hoş Geldiniz!")

    # Admin için ekstra sayfa seçeneği
    if st.session_state.is_admin:
        pages = ["Stok Ekle/Düzenle", "Ürün Tanımlama", "Raporlama"]
    else:
        pages = ["Stok Ekle/Düzenle", "Raporlama"]

    # Varsayılan sayfa "Stok Ekle/Düzenle" olarak ayarla
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "Stok Ekle/Düzenle"

    page = st.sidebar.radio("Sayfalar", pages, index=pages.index(st.session_state.current_page))
    st.session_state.current_page = page

    if st.sidebar.button("Çıkış Yap"):
        logout()

    if page == "Ürün Tanımlama" and st.session_state.is_admin:
        st.title("Ürün Tanımlama")

        with st.form("add_product_form"):
            product_name = st.text_input("Ürün Adı")

            if st.form_submit_button("Ürün Ekle"):
                if product_name:
                    success, message = add_product(product_name)
                    if success:
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)
                else:
                    st.error("Lütfen ürün adını giriniz")

        # Mevcut ürünleri göster
        st.subheader("Tanımlı Ürünler")
        products_df = get_products()
        if not products_df.empty:
            for _, row in products_df.iterrows():
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.write(row['name'])
                with col2:
                    if st.button("Sil", key=f"delete_{row['id']}"):
                        success, message = delete_product(row['id'])
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)
        else:
            st.info("Henüz ürün tanımlanmamış.")

    elif page == "Stok Ekle/Düzenle":
        st.title("Stok Güncelleme")

        products_df = get_products()
        if not products_df.empty:
            with st.form("update_stock_form"):
                product_id = st.selectbox(
                    "Ürün",
                    options=products_df['id'].tolist(),
                    format_func=lambda x: products_df[
                        products_df['id']==x
                    ]['name'].iloc[0]
                )

                col1, col2 = st.columns(2)
                with col1:
                    quantity = st.number_input(
                        "Miktar",
                        min_value=0.0,
                        step=0.1
                    )
                    # Birim seçimi
                    unit = st.selectbox(
                        "Birim", 
                        ["kg", "litre", "adet", "gram", "paket", "kova", "ml"]
                    )
                with col2:
                    total_price = st.number_input(
                        "Toplam Fiyat (TL)",
                        min_value=0.0,
                        step=0.1
                    )

                if st.form_submit_button("Güncelle"):
                    if quantity > 0 and total_price > 0:
                        success, message = add_inventory_movement(
                            product_id, quantity, unit, total_price,
                            st.session_state.user_id
                        )
                        if success:
                            st.success(message)
                            st.rerun()
                        else:
                            st.error(message)
                    else:
                        st.error("Miktar ve fiyat 0'dan büyük olmalıdır")

            # Son eklenen ürünleri göster
            latest_movements = get_latest_inventory_movements(5)
            if latest_movements:
                st.subheader("Son Eklenen Ürünler")
                for movement in latest_movements:
                    with st.container():
                        cols = st.columns([2, 2, 2, 2, 1])
                        with cols[0]:
                            st.write(f"**{movement['product_name']}**")
                        with cols[1]:
                            st.write(f"{movement['quantity']} {movement['unit']}")
                        with cols[2]:
                            st.write(f"Toplam: {movement['total_price']:.2f} TL")
                        with cols[3]:
                            if st.button("Sil", key=f"delete_movement_{movement['movement_id']}"):
                                success, message = delete_inventory_movement(movement['movement_id'])
                                if success:
                                    st.success(message)
                                    st.rerun()
                                else:
                                    st.error(message)
                        st.divider()
        else:
            st.warning("Henüz ürün tanımlanmamış. Lütfen önce ürün tanımlayınız.")

    elif page == "Raporlama":
        st.title("Stok ve Değer Raporu")

        col1, col2 = st.columns(2)
        with col1:
            start_date = st.date_input(
                "Başlangıç Tarihi",
                datetime.now() - timedelta(days=7)
            )
        with col2:
            end_date = st.date_input(
                "Bitiş Tarihi",
                datetime.now()
            )

        if st.button("Rapor Oluştur"):
            report_df = get_inventory_report(
                start_date.strftime('%Y-%m-%d'),
                end_date.strftime('%Y-%m-%d')
            )

            if not report_df.empty:
                # Toplam değeri göster
                total_value = report_df['total_value'].sum()
                st.metric("Toplam Stok Değeri", f"{total_value:.2f} TL")

                # Rapor tablosunu göster
                st.dataframe(report_df)

                excel_data = export_to_excel(report_df)
                st.download_button(
                    label="Excel'e Aktar",
                    data=excel_data,
                    file_name=f"stok_raporu_{start_date}_to_{end_date}.xlsx",
                    mime="application/vnd.ms-excel"
                )
            else:
                st.info("Seçilen tarih aralığında veri bulunmamaktadır.")