import pandas as pd
import streamlit as st
from datetime import datetime
import io

def export_to_excel(df):
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Stok Raporu', index=False)
        workbook = writer.book
        worksheet = writer.sheets['Stok Raporu']
        
        # Format ayarları
        header_format = workbook.add_format({
            'bold': True,
            'text_wrap': True,
            'valign': 'top',
            'bg_color': '#D7E4BC',
            'border': 1
        })
        
        # Başlıkları formatla
        for col_num, value in enumerate(df.columns.values):
            worksheet.write(0, col_num, value, header_format)
            
        # Sütun genişliklerini ayarla
        for idx, col in enumerate(df.columns):
            series = df[col]
            max_len = max(
                series.astype(str).apply(len).max(),
                len(str(series.name))
            ) + 1
            worksheet.set_column(idx, idx, max_len)
    
    return output.getvalue()

def format_date(date_str):
    return datetime.strptime(date_str, '%Y-%m-%d').strftime('%d.%m.%Y')
